For training, run:
python3 question_classifier.py train -config[configuration_file_path]

For testing, run:
python3 question_classifier.py test -config[configuration_file_path]

Example:
python question_classifier.py train -config ../data/bilstm.config

The program will load a configuration file storing all needed information, such as:
# Paths To Datasets And Evaluation
path_train : ../data/train.txt
path_dev : ../data/dev.txt
path_test : ../data/test.txt

# model
model : bow
path_model : ../data/model.bow

# Early Stopping
early_stopping : 50 *

# Model Settings 
epoch : 10 
lowercase : False **

# Using pre-trained Embeddings
pre_emb: True
path_pre_emb : ../data/glove.txt 

# Network Structure
word_embedding_dim : 200 ***
batch_size : 20  ****

# Hyperparameters
lr_param : 0.0001

# Evaluation
path_eval_result : ../data/output.txt *****


* Early stopping : We manage to implement this method but as we observe it doesn't make that much difference in our results so we removed it

** Lowercase: If you want to change this variable the two options you have is [True,False] <--- First letter with capital

*** Word Embedding Dimensions: If pre_emb: True then our programm ignores this variable as the embedding dimensions of glove is already 300

**** Batch_size: Only implemented for the bow model- It won't change anything if you use it for biLSTM. Our biLSTM take one by one the examples without the usage of batches.

***** We didn't save our evaluation somewhere because we didn't have the time.
