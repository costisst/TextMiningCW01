# -*- coding: utf-8 -*-
import math
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import numpy as np
from preprocesing import read_file,build_dictionary,pre_process,clean_numbers


def create_questions_tag_dict(questions_and_tags,lowercase):
    tags = []
    questions = []
    my_dictionary = {}
    for q in questions_and_tags:
        
        # Split tag and question
        tag,question = q.split(' ',1)
        
        question = pre_process(question,lowercase)
        
        # Add tag and question to corresponding list
        tags.append(tag)
        questions.append(question)
        
        # Enrich dictionary with words from questions
        bag_of_words = question.split(' ')
        for word in bag_of_words: 
            word = word.strip()
            if word:
                if word in my_dictionary:
                    my_dictionary[word] += 1
                else:
                    my_dictionary[word] = 1
                    
    return questions, tags, my_dictionary

def bag_of_words(question,my_dictionary):
    stopwords = read_file('../data/stopwords.txt')
    words = question.split(' ')
    if ' ' in words:
        words = [w for w in words if w != ' ']
    if '' in words:
        words = [w for w in words if w != '']
    words = [clean_numbers(w) for w in words]
    words = [w for w in words if w not in stopwords]
    words = ['#UNK#' if w not in my_dictionary else w for w in words ]
    indexes = [int(my_dictionary[w]) for w in words]
        
    return indexes

def pre_trained_dictionary():
    glove = open('../data/glove.small.txt')
    glove_dict = {}
    for line in glove:
        values = line.split()
        word = values[0]
        coefs = np.asarray(values[1:], dtype='float64')
        glove_dict[word] = coefs
    glove.close()
    # Add indexes to words
    glove_dict_words = glove_dict
    glove_dict_words = {word: i for i, word in enumerate(glove_dict)}
    return glove_dict,glove_dict_words

def create_train_dev_set(config):
    data = read_file("data/data.txt")
    # Remove the same examples
    data = set(data)
    data = list(data)

    # Create Training and Testing sets
    training_set = data[:math.floor(0.9*len(data))]

    dev_set = data[math.floor(0.9*len(data)):]
    
    with open('data/train.txt', 'w') as filehandle:
        filehandle.writelines("%s\n" % place for place in training_set)
    with open('data/dev.txt', 'w') as filehandle:
        filehandle.writelines("%s\n" % place for place in dev_set)
    
def prepare_sequence(seq, to_ix):
    idxs = [to_ix[w] for w in seq]
    return torch.tensor(idxs, dtype=torch.long)

def prepare_data(questions,tags):
    data = []
    for q,t in zip(questions,tags):
        ques = q.split()
        tues = [t for _ in range(len(ques))]
        d =  (ques, tues)
        data.append(d)
    return data

def prepare_tags_to_ix(unique_tags):
    tag_to_ix = {word: i for i, word in enumerate(unique_tags)}
    return tag_to_ix