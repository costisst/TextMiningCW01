# -*- coding: utf-8 -*-
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import math
import pickle
from preprocesing import read_file,build_dictionary
from models import create_questions_tag_dict,pre_trained_dictionary

def prepare_sequence(seq, to_ix):
    seq = ['#UNK#' if w not in to_ix else w for w in seq]
    idxs = [to_ix[w] for w in seq]
    return torch.tensor(idxs, dtype=torch.long)

def prepare_data(questions,tags):
    data = []
    for q,t in zip(questions,tags):
        ques = q.split()
        tues = [t for _ in range(len(ques))]
        d =  (ques, tues)
        data.append(d)
    return data

def prepare_tags_to_ix(unique_tags):
    tag_to_ix = {word: i for i, word in enumerate(unique_tags)}
    return tag_to_ix

def train_model(config,model,train_data,dev_data,vocabulary,tag_to_ix,test_data):
    loss_function = nn.NLLLoss()
    optimizer = optim.SGD(model.parameters(), config.lr_param)

    test_score = []
    train_score = []
    epochs = config.epoch
    for epoch in range(epochs):  # again, normally you would NOT do 300 epochs, it is toy data
        running_loss = 0
        count_samples = 0
        count_correct = 0
        count_samples_test = 0
        count_correct_test = 0
        # Training
        for sentence, tags in train_data:
            count_samples += 1
            # Step 1. Remember that Pytorch accumulates gradients.
            # We need to clear them out before each instance
            model.zero_grad()

            # Step 2. Get our inputs ready for the network, that is, turn them into
            # Tensors of word indices.
            sentence_in = prepare_sequence(sentence, vocabulary)
            targets = prepare_sequence(tags, tag_to_ix)

            # Step 3. Run our forward pass.
            tag_scores = model(sentence_in)

            # Step 4. Compute the loss, gradients, and update the parameters by
            #  calling optimizer.step()
            loss = loss_function(tag_scores, targets)

            if torch.eq(targets[-1], torch.exp(tag_scores[-1]).argmax()):
                count_correct += 1

            loss.backward()
            optimizer.step()

            running_loss += loss.item()

        # Validation
        for sentence, tags in dev_data:

            count_samples_test += 1

            sentence_in = prepare_sequence(sentence, vocabulary)
            targets = prepare_sequence(tags, tag_to_ix)

            tag_scores = model(sentence_in)

            loss = loss_function(tag_scores, targets)

            if torch.eq(targets[-1], torch.exp(tag_scores[-1]).argmax()):
                count_correct_test += 1

            running_loss += loss.item()

        test_score.append([count_correct_test/count_samples_test])
        train_score.append([count_correct/count_samples])
        print("Epochs: {0}".format(epoch))    
        print("Training loss: {0}".format(count_correct/count_samples))
        print("Validation loss: {0}".format(count_correct_test/count_samples_test))

    torch.save(model.state_dict(), config.path_model)

    with open('../data/tag_dict.pickle', 'wb') as handle:
        pickle.dump(tag_to_ix, handle, protocol=pickle.HIGHEST_PROTOCOL)



def test_model(config,test_data, device, weights, N, output_size,vocabulary,tag_to_ix,tags_test,model):
    EMBEDDING_DIM = config.word_embedding_dim
    HIDDEN_DIM = config.word_embedding_dim
    loss_function = nn.NLLLoss()
    state_dict = torch.load(config.path_model)
    model.load_state_dict(state_dict)        
    model.eval()

    count_samples_test = 0
    count_correct_test = 0
    for sentence, tags in test_data:

        count_samples_test += 1

        sentence_in = prepare_sequence(sentence, vocabulary)
        targets = prepare_sequence(tags, tag_to_ix)


        tag_scores = model(sentence_in)
        print('Target: {0} | Predicted: {1}'.format(targets[-1],tag_scores[-1].argmax()))

        loss = loss_function(tag_scores, targets)

        if torch.eq(targets[-1], torch.exp(tag_scores[-1]).argmax()):
            count_correct_test += 1

    print("Testing accuracy: {0}".format(count_correct_test/count_samples_test))
    
    #metrics = confusion_matrix(tag_to_ix, tags_test, tag_scores)
    #return metrics

def biLSTM(config, train_or_test):
    # Load data 
    # Only call this once to create your train,dev dataset
    #create_train_dev_set(config)

    # Red train and dev data from files
    train_data = read_file(config.path_train)
    train_data.remove('')
    dev_data = read_file(config.path_dev)
    dev_data.remove('') 
    test_data = read_file(config.path_test)
    test_data.remove('')

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

 
    # Create questions and tags list and the vocabulary 
    questions_train, tags_train, vocabulary  = create_questions_tag_dict(train_data,config.lowercase)
    questions_dev, tags_dev, _  = create_questions_tag_dict(dev_data,config.lowercase)
    questions_test, tags_test, _  = create_questions_tag_dict(test_data,config.lowercase)

    EMBEDDING_DIM = config.word_embedding_dim
    HIDDEN_DIM = config.word_embedding_dim

    if config.pre_train == 'False':    
        # Preprocess the dictionary
        vocabulary = build_dictionary(vocabulary)
        weights = None
    elif config.pre_train == 'True':
        EMBEDDING_DIM = 300
        HIDDEN_DIM = 300
        # Create dictionary with pretrained vectors
        glove_dict,glove_dict_words = pre_trained_dictionary()
        # Indexes for pretrained vectors
        pretrained_vectors = list(glove_dict.values())
        weights = torch.FloatTensor(pretrained_vectors)
        vocabulary = glove_dict_words

    # Tag dict
    unique_tags = set(tags_train)

    with open('../data/tag_dict.pickle', 'rb') as handle:
        tag_to_ix = pickle.load(handle)

    data_train = prepare_data(questions_train,tags_train)
    data_dev = prepare_data(questions_dev,tags_dev)
    data_test = prepare_data(questions_test,tags_test)

    if config.pre_train == 'False':
        model = LSTMTagger(EMBEDDING_DIM, HIDDEN_DIM, len(vocabulary), len(tag_to_ix),config)
    elif config.pre_train == 'True':
        model = LSTMTagger(EMBEDDING_DIM, HIDDEN_DIM, weights, len(tag_to_ix),config)

    if train_or_test == 'train':
        # Training
        train_model(config,model,data_train,data_dev,vocabulary,tag_to_ix,data_test)
    elif train_or_test == 'test':
        # Testing 
        metrics = test_model(config,data_test, device, weights, len(vocabulary), len(tag_to_ix),vocabulary,tag_to_ix,tags_test,model)
        print(metrics)

def confusion_matrix(tag_dict, true_label, predicted_label):
    
    # reversed_dict = dict((v,k) for k,v in tag_dict.items())
    label_list  = zip(true_label,predicted_label)
    label_list = list(label_list)
    label_list.sort()
    my_list = [(0,0)]*50
    previous_index = label_list[0][0]
    first_tup = 0
    second_tup = 0
    for true_index,predicted_index in label_list:
        if true_index == previous_index:
            first_tup = my_list[true_index][0] + 1
            if predicted_index == true_index:
                second_tup = my_list[true_index][1] + 1
        else:
            first_tup = 0
            second_tup = 0
            first_tup = my_list[true_index][0] + 1
            if predicted_index == true_index:
                second_tup = my_list[true_index][1] + 1
        my_list[true_index] = (first_tup,second_tup)        
        previous_index = true_index    
            
            
    confusion_matrix = np.zeros([50,50], dtype=int)
    for a,b in label_list:
        if a==b:
            confusion_matrix[a][a] += 1
        else:
            confusion_matrix[a][b] += 1        
            
    metrics = np.zeros([50,3])
    for i in range(0,50):
        
        if confusion_matrix[i][i] !=0 :
            recall = confusion_matrix[i][i] / (confusion_matrix[i][i] + (confusion_matrix[i,:].sum()-confusion_matrix[i][i]))
            precision = confusion_matrix[i][i] / (confusion_matrix[i][i] + (confusion_matrix[:,i].sum()-confusion_matrix[i][i]))
            f1_score = 2*((recall*precision)/(recall+precision))
        else:
            recall = 0
            precision = 0
            f1_score = 0
        
        metrics[i][0] = recall
        metrics[i][1] = precision
        metrics[i][2] = f1_score
        
    return metrics

class LSTMTagger(nn.Module):

    def __init__(self, embedding_dim, hidden_dim, weights, tagset_size,config):
        super(LSTMTagger, self).__init__()
        self.hidden_dim = hidden_dim
        if config.pre_train == 'False':
            self.word_embeddings = nn.Embedding(weights, embedding_dim)
        elif config.pre_train == 'True':
            self.word_embeddings = nn.Embedding.from_pretrained(weights)

        # The LSTM takes word embeddings as inputs, and outputs hidden states
        # with dimensionality hidden_dim.
        self.lstm = nn.LSTM(embedding_dim, hidden_dim,bidirectional=True)

        # The linear layer that maps from hidden state space to tag space
        self.hidden2tag = nn.Linear(hidden_dim*2, tagset_size)

    def forward(self, sentence):
        embeds = self.word_embeddings(sentence)
        lstm_out, _ = self.lstm(embeds.view(len(sentence), 1, -1))
        tag_space = self.hidden2tag(lstm_out.view(len(sentence), -1))
        tag_scores = F.log_softmax(tag_space, dim=1)
        return tag_scores