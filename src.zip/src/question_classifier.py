#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
from preprocesing import read_file
from config import Config
from bow_model import bow
from biLSTM_model import biLSTM

''' Main of question_classifier.py '''
if __name__ == '__main__':
    # read given arquments
    arguments = sys.argv[1:]
    
    # check if user gave the right command
    if len(arguments) < 2:
        print('Please provide train/test -config and the config file path')
        exit(1)
    
    # save config path and load it as an object
    config_path = arguments[2]
    conf = read_file(config_path)
    config = Config(conf)
    
    # Route
    if arguments[0] == 'train':
        # Training
        if config.model == 'bow':
            # Bow training
            print('\nBow_Training\n------------')
            bow(config,'train')
        if config.model == 'bilstm':
            # BiLSTM training
            print('\nbiLSTM_Training\n------------')
            biLSTM(config,'train')        
        
    elif arguments[0] == 'test':
        # Testing
        if config.model == 'bow':
            # Bow testing
            print('\nBow_Testing\n------------')
            bow(config,'test')
        if config.model == 'bilstm':
            # BiLSTM training
            print('\nbiLSTM_Testing\n------------')
            biLSTM(config,'test')
        
